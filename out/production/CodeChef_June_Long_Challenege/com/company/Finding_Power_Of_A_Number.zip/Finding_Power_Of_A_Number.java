import java.util.Scanner;

public class Finding_Power_Of_A_Number {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
//      Take input values of X and n.

        System.out.println("Enter the value of A");
        int A= sc.nextInt();
        System.out.println("Enter the value of B");
        int B= sc.nextInt();
//      To  retain values of A and n let us store them in separate variables as shown here.

        int n=B;
        int X=A;
        int result=1;

        while(n>0){
//          If n is an even number then multiply X with  itself  and make n as half of it.
            if(n%2==0) {
                X=X*X;
                n = n / 2;
            }
//          If n is an odd number then multiply result with X and reduce n by 1(one).
            else{
                result*=X;
                n--;
            }
        }

        System.out.println("The value of  "+A+" power "+B+"  is "+result);
    }
}
